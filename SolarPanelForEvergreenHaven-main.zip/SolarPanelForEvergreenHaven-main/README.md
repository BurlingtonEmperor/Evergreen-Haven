# Solar Panel Simulator

An interactive web-based simulator that models solar panel energy production based on environmental conditions and panel configurations.

## Features

- **Visual Simulation**: Interactive 3D-like visualization of solar panels and sun position throughout the day
- **Real-time Data**: View immediate power output as you adjust time, weather, and panel settings
- **Complex Modeling**: Simulates multiple factors affecting solar production:
  - Panel count, efficiency, angle, and orientation
  - Time of day and seasonal variations
  - Geographic location
  - Weather conditions
  - Temperature effects
- **Data Visualization**: Charts showing daily power output and monthly energy production
- **Educational Tool**: Learn about solar energy production factors and optimization

## Technical Details

The simulator implements several physics-based models including:
- Solar position calculation based on time, season, and location
- Irradiance modeling that varies with sun position and weather conditions
- Panel efficiency calculations accounting for temperature, angle, and orientation
- Accurate day/night cycles across different seasons

The project is built with:
- Vanilla JavaScript (no frameworks)
- HTML5 & CSS3
- Chart.js for data visualization

## How to Use

1. **Load the page**: Open `index.html` in any modern web browser
2. **Configure System**: Adjust panel and environmental settings in the control panel
3. **Run Simulation**: Click the "Run Simulation" button to calculate outputs
4. **Explore Results**: View power output and efficiency metrics
5. **Time Control**: Use the time slider or play button to see how power output changes throughout the day

## Optimization Tips

- The optimal panel angle is approximately equal to your latitude
- South-facing panels (in Northern Hemisphere) generally produce the most energy
- Panel efficiency decreases as temperature increases
- Clear days in summer typically yield the highest output
- Different climates may benefit from different panel configurations

## Getting Started

Simply clone the repository and open `index.html` in your browser:

```bash
git clone https://github.com/yourusername/solar-panel-simulator.git
cd solar-panel-simulator
# Open index.html in your browser
```

No build process or server is required. 