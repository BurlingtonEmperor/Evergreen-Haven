// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize the simulation components
    initializeSimulation();
    
    // Log that initialization is complete
    console.log('Solar Panel Simulator initialized');
});

/**
 * Initialize the simulation components and event listeners
 */
function initializeSimulation() {
    try {
        console.log('Initializing simulation...');
        
        // Create solar panel and environment with default configurations
        const solarPanel = new SolarPanel();
        const environment = new Environment();
        
        // Create simulation with the components
        const simulation = new Simulation(solarPanel, environment);
        
        // Create visualization
        const visualization = new Visualization(simulation);
        
        // Set up configuration form event listeners
        setupConfigListeners(simulation, visualization);
        
        // Run initial simulation
        runSimulation(simulation, visualization);
        
        // Initial sun position update
        visualization.updateSunPosition(simulation.currentHour);
        
        // Additional safety check for button functionality
        ensureButtonFunctionality(simulation, visualization);
        
        console.log('Initialization completed successfully');
    } catch (error) {
        console.error('Error during initialization:', error);
    }
}

/**
 * Ensure button functionality as a safeguard
 */
function ensureButtonFunctionality(simulation, visualization) {
    const playPauseButton = document.getElementById('play-pause');
    const runSimulationButton = document.getElementById('run-simulation');
    
    // Ensure Play/Pause button works
    if (playPauseButton) {
        console.log('Setting up play/pause button');
        playPauseButton.addEventListener('click', () => {
            console.log('Play/Pause clicked');
            if (visualization.isAnimating) {
                visualization.stopAnimation();
                playPauseButton.textContent = 'Play';
            } else {
                visualization.startAnimation();
                playPauseButton.textContent = 'Pause';
            }
        });
    } else {
        console.error('Play/Pause button not found');
    }
    
    // Ensure Run Simulation button works
    if (runSimulationButton) {
        console.log('Setting up run simulation button');
        // We'll keep the existing listener in setupConfigListeners,
        // but add this as a safeguard
    } else {
        console.error('Run Simulation button not found');
    }
}

/**
 * Set up configuration form event listeners
 * @param {Simulation} simulation - The simulation instance
 * @param {Visualization} visualization - The visualization instance
 */
function setupConfigListeners(simulation, visualization) {
    // Panel configuration elements
    const panelCountInput = document.getElementById('panel-count');
    const panelEfficiencyInput = document.getElementById('panel-efficiency');
    const panelAngleInput = document.getElementById('panel-angle');
    const panelOrientationSelect = document.getElementById('panel-orientation');
    
    // Environment configuration elements
    const seasonSelect = document.getElementById('season');
    const locationSelect = document.getElementById('location');
    const weatherSelect = document.getElementById('weather');
    const temperatureInput = document.getElementById('temperature');
    
    // Run simulation button
    const runSimulationButton = document.getElementById('run-simulation');
    
    // Add event listener to run simulation button
    runSimulationButton.addEventListener('click', () => {
        // Get panel configuration
        const panelConfig = {
            count: parseInt(panelCountInput.value),
            efficiency: parseFloat(panelEfficiencyInput.value),
            angle: parseInt(panelAngleInput.value),
            orientation: panelOrientationSelect.value
        };
        
        // Get environment configuration
        const envConfig = {
            season: seasonSelect.value,
            location: locationSelect.value,
            weather: weatherSelect.value,
            baseTemperature: parseFloat(temperatureInput.value)
        };
        
        // Update configurations
        simulation.updateConfigurations(panelConfig, envConfig);
        
        // Create solar panels with new count
        visualization.createSolarPanels();
        
        // Update panel angle display
        visualization.updatePanelAngle(panelConfig.angle);
        
        // Run the simulation
        runSimulation(simulation, visualization);
    });
}

/**
 * Run the simulation and update visualization
 * @param {Simulation} simulation - The simulation instance
 * @param {Visualization} visualization - The visualization instance
 */
function runSimulation(simulation, visualization) {
    console.log('Running simulation...');
    
    // Add visual feedback
    const runButton = document.getElementById('run-simulation');
    if (runButton) {
        // Add temporary active class for visual feedback
        runButton.classList.add('active');
        runButton.textContent = 'Simulating...';
        
        // Remove active class after simulation completes
        setTimeout(() => {
            runButton.classList.remove('active');
            runButton.textContent = 'Run Simulation';
        }, 1000);
    }
    
    // Run daily simulation
    simulation.runDailySimulation();
    
    // Run yearly simulation for monthly chart
    simulation.runYearlySimulation();
    
    // Update visualizations with results
    visualization.updateVisualization();
    
    // Update current output for current time
    visualization.updateCurrentOutput();
    
    // Update sun position for current time
    visualization.updateSunPosition(simulation.currentHour);
    
    console.log('Simulation completed');
} 