/**
 * Class representing environmental conditions for solar simulation
 */
class Environment {
    /**
     * Create an environment model
     * @param {Object} config - Environment configuration
     * @param {string} config.season - Season (summer, autumn, winter, spring)
     * @param {string} config.location - Geographic location type
     * @param {string} config.weather - Weather condition
     * @param {number} config.baseTemperature - Base temperature in Celsius
     */
    constructor(config = {}) {
        this.season = config.season || 'summer';
        this.location = config.location || 'temperate';
        this.weather = config.weather || 'clear';
        this.baseTemperature = config.baseTemperature || 25;
        this.latitude = this.getLocationLatitude(this.location);
        
        // Set weather and location impact factors
        this.setWeatherFactors();
        this.setLocationFactors();
        this.setSeasonFactors();
    }
    
    /**
     * Update environment configuration
     * @param {Object} config - Configuration parameters to update
     */
    updateConfig(config = {}) {
        if (config.season !== undefined) this.season = config.season;
        if (config.location !== undefined) this.location = config.location;
        if (config.weather !== undefined) this.weather = config.weather;
        if (config.baseTemperature !== undefined) this.baseTemperature = config.baseTemperature;
        
        // Update derived values
        this.latitude = this.getLocationLatitude(this.location);
        this.setWeatherFactors();
        this.setLocationFactors();
        this.setSeasonFactors();
    }
    
    /**
     * Set weather impact factors
     */
    setWeatherFactors() {
        // Define irradiance reduction factors for different weather conditions
        const weatherFactors = {
            'clear': { irradianceFactor: 1.0, temperatureOffset: 0 },
            'partly-cloudy': { irradianceFactor: 0.7, temperatureOffset: -2 },
            'cloudy': { irradianceFactor: 0.4, temperatureOffset: -4 },
            'rainy': { irradianceFactor: 0.2, temperatureOffset: -6 }
        };
        
        // Set weather factors
        const factors = weatherFactors[this.weather] || weatherFactors.clear;
        this.weatherIrradianceFactor = factors.irradianceFactor;
        this.weatherTemperatureOffset = factors.temperatureOffset;
    }
    
    /**
     * Set location impact factors
     */
    setLocationFactors() {
        // Define location-based factors
        const locationFactors = {
            'desert': { baseIrradiance: 1000, temperatureRange: 20, temperatureOffset: 8 },
            'temperate': { baseIrradiance: 850, temperatureRange: 12, temperatureOffset: 0 },
            'tropical': { baseIrradiance: 900, temperatureRange: 8, temperatureOffset: 5 },
            'arctic': { baseIrradiance: 700, temperatureRange: 15, temperatureOffset: -10 }
        };
        
        // Set location factors
        const factors = locationFactors[this.location] || locationFactors.temperate;
        this.baseIrradiance = factors.baseIrradiance;
        this.temperatureRange = factors.temperatureRange;
        this.locationTemperatureOffset = factors.temperatureOffset;
    }
    
    /**
     * Set seasonal factors
     */
    setSeasonFactors() {
        // Define seasonal adjustments
        const seasonFactors = {
            'summer': { dayLengthFactor: 1.0, irradianceFactor: 1.0, temperatureOffset: 5 },
            'autumn': { dayLengthFactor: 0.8, irradianceFactor: 0.8, temperatureOffset: 0 },
            'winter': { dayLengthFactor: 0.6, irradianceFactor: 0.6, temperatureOffset: -5 },
            'spring': { dayLengthFactor: 0.8, irradianceFactor: 0.8, temperatureOffset: 0 }
        };
        
        // Set season factors
        const factors = seasonFactors[this.season] || seasonFactors.summer;
        this.seasonDayLengthFactor = factors.dayLengthFactor;
        this.seasonIrradianceFactor = factors.irradianceFactor;
        this.seasonTemperatureOffset = factors.temperatureOffset;
    }
    
    /**
     * Get approximate latitude for a location type
     * @param {string} location - Location type
     * @returns {number} - Approximate latitude in degrees
     */
    getLocationLatitude(location) {
        const latitudes = {
            'desert': 30,
            'temperate': 45,
            'tropical': 15,
            'arctic': 60
        };
        
        return latitudes[location] || latitudes.temperate;
    }
    
    /**
     * Calculate temperature at a specific time of day
     * @param {number} hour - Hour of the day (0-23)
     * @returns {number} - Temperature in Celsius
     */
    getTemperature(hour) {
        // Convert hour to a value between 0 (coldest) and 1 (warmest)
        // Warmest at ~14:00, coldest at ~2:00 (2 AM)
        const tempCycleFactor = Math.sin((hour - 2) * Math.PI / 24) * 0.5 + 0.5;
        
        // Calculate temperature based on all factors
        const temperature = this.baseTemperature +
            this.locationTemperatureOffset +
            this.seasonTemperatureOffset +
            this.weatherTemperatureOffset +
            (this.temperatureRange * tempCycleFactor - this.temperatureRange / 2);
        
        return Math.round(temperature * 10) / 10; // Round to 1 decimal place
    }
    
    /**
     * Calculate sun position for a given time
     * @param {number} hour - Hour of the day (0-23)
     * @returns {Object} - Sun position data
     */
    getSunPosition(hour) {
        // Adjust day length based on season
        const dayLength = 12 * this.seasonDayLengthFactor;
        const halfDayLength = dayLength / 2;
        
        // Calculate adjusted sunrise and sunset times
        const sunrise = 12 - halfDayLength;
        const sunset = 12 + halfDayLength;
        
        // Night time (before sunrise or after sunset)
        if (hour < sunrise || hour > sunset) {
            return {
                sunElevation: 0,
                sunAzimuth: hour < 12 ? 90 : 270, // East at morning, West at evening
                irradiance: 0
            };
        }
        
        // Calculate sun elevation (0 at horizon, max at noon)
        const relativeHour = (hour - sunrise) / dayLength;
        const midday = sunrise + halfDayLength;
        
        // Maximum elevation based on latitude and season
        // This is a simplified model that approximates seasonal sun paths
        let maxElevation = 90 - this.latitude;
        if (this.season === 'summer') maxElevation += 23.5;
        else if (this.season === 'winter') maxElevation -= 23.5;
        
        // Calculate sun elevation - follows a sine curve
        const sunElevation = Math.sin(relativeHour * Math.PI) * maxElevation;
        
        // Calculate sun azimuth (angle from north, clockwise)
        // Simplified model: 90° (east) at sunrise, 180° (south) at noon, 270° (west) at sunset
        let sunAzimuth;
        if (hour < midday) {
            // Morning: Sunrise (90°) to noon (180°)
            sunAzimuth = 90 + (hour - sunrise) * (90 / halfDayLength);
        } else {
            // Afternoon: Noon (180°) to sunset (270°)
            sunAzimuth = 180 + (hour - midday) * (90 / halfDayLength);
        }
        
        // Calculate base irradiance - follows a sine curve, max at midday
        let irradiance = Math.sin(relativeHour * Math.PI) * this.baseIrradiance;
        
        // Apply weather and season factors
        irradiance *= this.weatherIrradianceFactor * this.seasonIrradianceFactor;
        
        return {
            sunElevation,
            sunAzimuth,
            irradiance
        };
    }
    
    /**
     * Generate a daily dataset of environmental conditions
     * @returns {Array} - Array of hourly environmental data
     */
    generateDailyData() {
        const dailyData = [];
        
        for (let hour = 0; hour < 24; hour++) {
            const sunPosition = this.getSunPosition(hour);
            const temperature = this.getTemperature(hour);
            
            dailyData.push({
                hour,
                ...sunPosition,
                temperature
            });
        }
        
        return dailyData;
    }
} 