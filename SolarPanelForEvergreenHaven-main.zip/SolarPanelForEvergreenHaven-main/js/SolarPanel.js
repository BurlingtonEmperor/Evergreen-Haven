/**
 * Class representing a solar panel system
 */
class SolarPanel {
    /**
     * Create a solar panel system
     * @param {Object} config - Panel configuration
     * @param {number} config.count - Number of panels
     * @param {number} config.efficiency - Panel efficiency as percentage (e.g., 18 for 18%)
     * @param {number} config.angle - Panel tilt angle in degrees
     * @param {string} config.orientation - Panel orientation (e.g., 'south', 'southeast')
     * @param {number} config.area - Area of a single panel in m²
     */
    constructor(config = {}) {
        this.count = config.count || 12;
        this.efficiency = config.efficiency || 18;
        this.angle = config.angle || 35;
        this.orientation = config.orientation || 'south';
        this.area = config.area || 1.7; // Default panel size in m²
        
        // Calculate total area
        this.totalArea = this.count * this.area;
        
        // Standard Test Conditions (STC) power output per m² (1000 W/m² * efficiency)
        this.peakPowerPerM2 = 1000 * (this.efficiency / 100);
        
        // Calculate peak power of the whole system in Watts
        this.peakPower = this.peakPowerPerM2 * this.totalArea;
    }
    
    /**
     * Update the panel configuration
     * @param {Object} config - Panel configuration parameters to update
     */
    updateConfig(config = {}) {
        if (config.count !== undefined) this.count = config.count;
        if (config.efficiency !== undefined) this.efficiency = config.efficiency;
        if (config.angle !== undefined) this.angle = config.angle;
        if (config.orientation !== undefined) this.orientation = config.orientation;
        if (config.area !== undefined) this.area = config.area;
        
        // Recalculate derived values
        this.totalArea = this.count * this.area;
        this.peakPowerPerM2 = 1000 * (this.efficiency / 100);
        this.peakPower = this.peakPowerPerM2 * this.totalArea;
    }
    
    /**
     * Calculate orientation efficiency factor based on panel orientation and sun position
     * @param {number} sunAzimuth - Sun's azimuth angle in degrees (0 = North, 90 = East, 180 = South, 270 = West)
     * @returns {number} - Orientation efficiency factor (0-1)
     */
    getOrientationFactor(sunAzimuth) {
        // Convert orientation strings to approximate azimuth angles
        const orientationAngles = {
            'north': 0,
            'northeast': 45,
            'east': 90,
            'southeast': 135,
            'south': 180,
            'southwest': 225,
            'west': 270,
            'northwest': 315
        };
        
        // Get panel azimuth from orientation
        const panelAzimuth = orientationAngles[this.orientation] || 180; // Default to South
        
        // Calculate the absolute angle difference between panel and sun
        let angleDiff = Math.abs(panelAzimuth - sunAzimuth);
        
        // Normalize to the smaller angle (maximum difference is 180 degrees)
        if (angleDiff > 180) {
            angleDiff = 360 - angleDiff;
        }
        
        // Calculate orientation factor (1 when perfectly aligned, decreasing to 0 at 90 degrees difference)
        return Math.cos(angleDiff * Math.PI / 180);
    }
    
    /**
     * Calculate tilt efficiency factor based on panel tilt and sun elevation
     * @param {number} sunElevation - Sun's elevation angle in degrees (0 = horizon, 90 = zenith)
     * @returns {number} - Tilt efficiency factor (0-1)
     */
    getTiltFactor(sunElevation) {
        // Optimal panel angle is approximately (90 - sunElevation)
        const optimalAngle = 90 - sunElevation;
        
        // Calculate the angle difference between panel tilt and optimal angle
        const angleDiff = Math.abs(this.angle - optimalAngle);
        
        // Calculate tilt factor
        return Math.cos(angleDiff * Math.PI / 180);
    }
    
    /**
     * Calculate temperature efficiency factor
     * @param {number} temperature - Ambient temperature in Celsius
     * @returns {number} - Temperature efficiency factor (usually 0.9-1.0)
     */
    getTemperatureFactor(temperature) {
        // Solar panels typically lose efficiency at rate of about 0.4-0.5% per degree C above 25°C
        const referenceTemp = 25; // Standard Test Conditions temperature
        const tempCoefficientPct = -0.45; // Typical value for silicon PV cells
        
        if (temperature <= referenceTemp) {
            return 1.0; // No efficiency loss below reference temperature
        } else {
            const tempDiff = temperature - referenceTemp;
            return 1 + (tempDiff * (tempCoefficientPct / 100));
        }
    }
    
    /**
     * Calculate power output based on environmental conditions
     * @param {Object} environment - Environmental conditions
     * @param {number} environment.irradiance - Solar irradiance in W/m²
     * @param {number} environment.temperature - Ambient temperature in Celsius
     * @param {number} environment.sunElevation - Sun's elevation in degrees
     * @param {number} environment.sunAzimuth - Sun's azimuth in degrees
     * @returns {number} - Power output in Watts
     */
    calculatePowerOutput(environment) {
        // Get adjustment factors
        const orientationFactor = this.getOrientationFactor(environment.sunAzimuth);
        const tiltFactor = this.getTiltFactor(environment.sunElevation);
        const temperatureFactor = this.getTemperatureFactor(environment.temperature);
        
        // Calculate effective irradiance based on panel orientation and tilt
        const effectiveIrradiance = environment.irradiance * orientationFactor * tiltFactor;
        
        // Calculate power output
        const outputRatio = effectiveIrradiance / 1000; // Ratio to standard test conditions (1000 W/m²)
        const temperature_adjusted_efficiency = this.efficiency * temperatureFactor;
        
        // Power output in Watts
        const powerOutput = this.totalArea * effectiveIrradiance * (temperature_adjusted_efficiency / 100);
        
        return Math.max(0, powerOutput); // Ensure non-negative output
    }
    
    /**
     * Estimate daily energy production based on location and season
     * @param {Object} environment - Environment configuration
     * @returns {Object} - Energy production data for a day
     */
    estimateDailyProduction(environment) {
        const hourlyProduction = [];
        let totalEnergy = 0;
        let peakPower = 0;
        
        // Calculate power output for each hour of the day
        for (let hour = 0; hour < 24; hour++) {
            // Get sun position and irradiance for this hour
            const timeOfDay = hour;
            const { sunElevation, sunAzimuth, irradiance } = environment.getSunPosition(timeOfDay);
            
            // Calculate environmental conditions for this hour
            const conditions = {
                irradiance,
                temperature: environment.getTemperature(timeOfDay),
                sunElevation,
                sunAzimuth
            };
            
            // Calculate power output for this hour
            const powerOutput = this.calculatePowerOutput(conditions);
            
            // Track peak power
            if (powerOutput > peakPower) {
                peakPower = powerOutput;
            }
            
            // Add to total energy (convert W to kWh)
            totalEnergy += powerOutput / 1000;
            
            // Store hourly production
            hourlyProduction.push({
                hour,
                power: powerOutput,
                energy: powerOutput / 1000
            });
        }
        
        return {
            hourlyProduction,
            totalEnergy,
            peakPower,
            efficiencyFactor: (peakPower / this.peakPower) * 100
        };
    }
} 