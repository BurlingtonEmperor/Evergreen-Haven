// Debug script to check for issues with the buttons
document.addEventListener('DOMContentLoaded', () => {
    // Check if buttons exist
    const playPauseButton = document.getElementById('play-pause');
    const runSimulationButton = document.getElementById('run-simulation');
    
    console.log('Debug: Play/Pause button exists:', !!playPauseButton);
    console.log('Debug: Run Simulation button exists:', !!runSimulationButton);
    
    // Add debug event listeners
    if (playPauseButton) {
        console.log('Debug: Adding test listener to Play/Pause button');
        playPauseButton.addEventListener('click', () => {
            console.log('Debug: Play/Pause button clicked');
        });
    }
    
    if (runSimulationButton) {
        console.log('Debug: Adding test listener to Run Simulation button');
        runSimulationButton.addEventListener('click', () => {
            console.log('Debug: Run Simulation button clicked');
        });
    }
    
    // Check for other potential issues
    console.log('Debug: Checking Chart.js is loaded:', typeof Chart !== 'undefined');
    
    // Log objects to see if they're properly instantiated
    window.setTimeout(() => {
        console.log('Debug: Solar panel array element exists:', !!document.getElementById('solarPanelArray'));
        console.log('Debug: Current output display exists:', !!document.getElementById('current-output'));
        console.log('Debug: Sun element exists:', !!document.querySelector('.sun'));
    }, 1000);
}); 