/**
 * Class for handling visual aspects of the solar panel simulation
 */
class Visualization {
    /**
     * Create a visualization handler
     * @param {Simulation} simulation - The simulation object
     */
    constructor(simulation) {
        this.simulation = simulation;
        this.animationFrameId = null;
        this.isAnimating = false;
        this.dailyOutputChart = null;
        this.monthlyProductionChart = null;
        
        // DOM elements
        this.solarPanelArray = document.getElementById('solarPanelArray');
        this.sun = document.querySelector('.sun');
        this.timeSlider = document.getElementById('time-slider');
        this.timeDisplay = document.getElementById('time-display');
        this.playPauseButton = document.getElementById('play-pause');
        
        // Output display elements - now with duplicates
        this.currentOutputDisplay = document.getElementById('current-output');
        this.dailyEnergyDisplay = document.getElementById('daily-energy');
        this.currentOutputDetailDisplay = document.getElementById('current-output-detail');
        this.dailyEnergyDetailDisplay = document.getElementById('daily-energy-detail');
        this.peakPowerDisplay = document.getElementById('peak-power');
        this.efficiencyFactorDisplay = document.getElementById('efficiency-factor');
        
        // Chart canvases
        this.dailyOutputCanvas = document.getElementById('daily-output-chart');
        this.monthlyProductionCanvas = document.getElementById('monthly-production-chart');
        
        // Initialize panel angle display
        this.panelAngleInput = document.getElementById('panel-angle');
        this.panelAngleValue = document.getElementById('panel-angle-value');
        
        this.initializeVisualElements();
    }
    
    /**
     * Initialize visual elements and event listeners
     */
    initializeVisualElements() {
        this.createSolarPanels();
        this.initializePanelAngleDisplay();
        this.initializeTimeControls();
        this.initializeCharts();
    }
    
    /**
     * Create solar panel elements
     */
    createSolarPanels() {
        // Clear existing panels
        this.solarPanelArray.innerHTML = '';
        
        // Calculate rows and columns for a grid layout
        const panelCount = this.simulation.solarPanel.count;
        const columns = Math.min(6, Math.ceil(Math.sqrt(panelCount)));
        const rows = Math.ceil(panelCount / columns);
        
        // Create panel elements
        for (let i = 0; i < panelCount; i++) {
            const panel = document.createElement('div');
            panel.className = 'solar-panel';
            this.solarPanelArray.appendChild(panel);
        }
        
        // Update panel angle
        this.updatePanelAngle(this.simulation.solarPanel.angle);
    }
    
    /**
     * Initialize panel angle input display and event listener
     */
    initializePanelAngleDisplay() {
        this.panelAngleValue.textContent = `${this.panelAngleInput.value}°`;
        
        // Add event listener to update angle value display
        this.panelAngleInput.addEventListener('input', () => {
            const angle = parseInt(this.panelAngleInput.value);
            this.panelAngleValue.textContent = `${angle}°`;
            this.updatePanelAngle(angle);
        });
    }
    
    /**
     * Update solar panel angle in visualization
     * @param {number} angle - Panel angle in degrees
     */
    updatePanelAngle(angle) {
        const panels = this.solarPanelArray.querySelectorAll('.solar-panel');
        panels.forEach(panel => {
            panel.style.transform = `rotateX(${angle}deg)`;
        });
    }
    
    /**
     * Initialize time slider and play/pause controls
     */
    initializeTimeControls() {
        // Initialize time display
        this.updateTimeDisplay(this.timeSlider.value);
        
        // Add event listener for time slider
        this.timeSlider.addEventListener('input', () => {
            const hour = parseFloat(this.timeSlider.value);
            this.updateTimeDisplay(hour);
            this.simulation.setCurrentHour(hour);
            this.updateSunPosition(hour);
            this.updateCurrentOutput();
        });
        
        // Add event listener for play/pause button
        this.playPauseButton.addEventListener('click', () => {
            if (this.isAnimating) {
                this.stopAnimation();
                this.playPauseButton.textContent = 'Play';
            } else {
                this.startAnimation();
                this.playPauseButton.textContent = 'Pause';
            }
        });
    }
    
    /**
     * Update time display
     * @param {number} hour - Hour of the day (0-23.99)
     */
    updateTimeDisplay(hour) {
        const hours = Math.floor(hour);
        const minutes = Math.floor((hour - hours) * 60);
        
        // Format as HH:MM
        const formattedHours = hours.toString().padStart(2, '0');
        const formattedMinutes = minutes.toString().padStart(2, '0');
        
        this.timeDisplay.textContent = `${formattedHours}:${formattedMinutes}`;
    }
    
    /**
     * Start time animation
     */
    startAnimation() {
        if (this.isAnimating) return;
        
        console.log('Starting animation');
        this.isAnimating = true;
        
        // Update button appearance
        if (this.playPauseButton) {
            this.playPauseButton.textContent = 'Pause';
            this.playPauseButton.classList.add('active');
        }
        
        const animate = () => {
            if (!this.isAnimating) return;
            
            // Get current time from slider
            let hour = parseFloat(this.timeSlider.value);
            
            // Increment time (in 5-minute increments)
            hour += 0.08; // Approximately 5 minutes
            
            // Loop back to 0 after 24 hours
            if (hour >= 24) {
                hour = 0;
            }
            
            // Update slider value
            this.timeSlider.value = hour;
            
            // Update display
            this.updateTimeDisplay(hour);
            this.simulation.setCurrentHour(hour);
            this.updateSunPosition(hour);
            this.updateCurrentOutput();
            
            // Continue animation
            this.animationFrameId = requestAnimationFrame(animate);
        };
        
        // Start animation loop
        this.animationFrameId = requestAnimationFrame(animate);
    }
    
    /**
     * Stop time animation
     */
    stopAnimation() {
        console.log('Stopping animation');
        this.isAnimating = false;
        
        // Update button appearance
        if (this.playPauseButton) {
            this.playPauseButton.textContent = 'Play';
            this.playPauseButton.classList.remove('active');
        }
        
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
    }
    
    /**
     * Update sun position based on time of day
     * @param {number} hour - Hour of the day (0-23.99)
     */
    updateSunPosition(hour) {
        const { sunElevation, sunAzimuth } = this.simulation.environment.getSunPosition(hour);
        
        // Calculate sun position in the scene
        // Normalized azimuth (0-1 for morning to evening)
        const normalizedAzimuth = (sunAzimuth - 90) / 180;
        
        // Calculate x position (left to right)
        const sceneWidth = this.sun.parentElement.offsetWidth;
        const xPos = normalizedAzimuth * sceneWidth;
        
        // Calculate y position (top to bottom, inverted)
        const sceneHeight = this.sun.parentElement.offsetHeight - 80; // Subtract ground height
        const normalizedElevation = sunElevation / 90; // 0-1
        const yPos = sceneHeight - (normalizedElevation * sceneHeight);
        
        // Apply position (with constraints to keep sun in view)
        const sunRadius = this.sun.offsetWidth / 2;
        const constrainedX = Math.max(sunRadius, Math.min(xPos, sceneWidth - sunRadius));
        const constrainedY = Math.max(sunRadius, Math.min(yPos, sceneHeight - sunRadius));
        
        this.sun.style.left = `${constrainedX}px`;
        this.sun.style.top = `${constrainedY}px`;
        
        // Update sun size and brightness based on elevation
        // Larger and brighter at noon, smaller and dimmer at horizon
        const sizeScale = 0.7 + (normalizedElevation * 0.3);
        const opacityScale = 0.5 + (normalizedElevation * 0.5);
        
        this.sun.style.transform = `translateX(-50%) scale(${sizeScale})`;
        this.sun.style.opacity = opacityScale;
        
        // Night time (sun below horizon)
        if (sunElevation <= 0) {
            this.sun.style.display = 'none';
            this.sun.parentElement.style.background = 'linear-gradient(to bottom, #0a1a2a 0%, #0a1a2a 100%)';
        } else {
            this.sun.style.display = 'block';
            
            // Update sky color based on sun elevation
            const skyBlue = Math.round(135 + normalizedElevation * 120);
            this.sun.parentElement.style.background = `linear-gradient(to bottom, #87ceeb 0%, rgb(179, ${skyBlue}, 255) 100%)`;
        }
    }
    
    /**
     * Update current output display
     */
    updateCurrentOutput() {
        // Get current output
        const currentOutput = this.simulation.getCurrentPowerOutput();
        
        // Format and display
        const formattedOutput = this.simulation.formatPower(currentOutput);
        this.currentOutputDisplay.textContent = formattedOutput;
        
        // Update the detail view as well if it exists
        if (this.currentOutputDetailDisplay) {
            this.currentOutputDetailDisplay.textContent = formattedOutput;
        }
    }
    
    /**
     * Initialize charts
     */
    initializeCharts() {
        // Create empty daily output chart
        this.dailyOutputChart = new Chart(this.dailyOutputCanvas, {
            type: 'line',
            data: {
                labels: Array.from({ length: 24 }, (_, i) => i),
                datasets: [{
                    label: 'Power Output (W)',
                    data: Array(24).fill(0),
                    borderColor: '#2a80b9',
                    backgroundColor: 'rgba(42, 128, 185, 0.2)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Hour of Day'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Power (W)'
                        },
                        min: 0
                    }
                }
            }
        });
        
        // Create empty monthly production chart
        this.monthlyProductionChart = new Chart(this.monthlyProductionCanvas, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Energy (kWh)',
                    data: Array(12).fill(0),
                    backgroundColor: '#f1c40f',
                    borderColor: '#f39c12',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Month'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Energy (kWh)'
                        },
                        min: 0
                    }
                }
            }
        });
    }
    
    /**
     * Update the charts with simulation results
     */
    updateCharts() {
        try {
            console.log('Updating charts...');
            
            if (!this.simulation.simulationResults) {
                console.warn('No simulation results available to update charts');
                return;
            }
            
            // Check if charts are initialized
            if (!this.dailyOutputChart || !this.monthlyProductionChart) {
                console.warn('Charts not initialized. Reinitializing...');
                this.initializeCharts();
            }
            
            // Update daily output chart
            if (this.dailyOutputChart && this.simulation.simulationResults.hourlyProduction) {
                const hourlyData = this.simulation.simulationResults.hourlyProduction.map(hour => hour.power);
                this.dailyOutputChart.data.datasets[0].data = hourlyData;
                this.dailyOutputChart.update();
                console.log('Daily output chart updated');
            } else {
                console.warn('Could not update daily output chart');
            }
            
            // Update monthly production chart if available
            if (this.monthlyProductionChart && this.simulation.monthlyData) {
                const monthlyEnergy = this.simulation.monthlyData.map(month => month.monthlyEnergy);
                this.monthlyProductionChart.data.datasets[0].data = monthlyEnergy;
                this.monthlyProductionChart.update();
                console.log('Monthly production chart updated');
            } else {
                console.warn('Could not update monthly production chart');
            }
        } catch (error) {
            console.error('Error updating charts:', error);
        }
    }
    
    /**
     * Update all output displays with simulation results
     */
    updateOutputDisplays() {
        if (!this.simulation.simulationResults) return;
        
        const formattedResults = this.simulation.getFormattedResults();
        
        // Update both instances of the outputs
        this.currentOutputDisplay.textContent = formattedResults.currentOutput;
        this.dailyEnergyDisplay.textContent = formattedResults.dailyEnergy;
        
        // Update the detail view as well
        if (this.currentOutputDetailDisplay) {
            this.currentOutputDetailDisplay.textContent = formattedResults.currentOutput;
        }
        if (this.dailyEnergyDetailDisplay) {
            this.dailyEnergyDetailDisplay.textContent = formattedResults.dailyEnergy;
        }
        
        this.peakPowerDisplay.textContent = formattedResults.peakPower;
        this.efficiencyFactorDisplay.textContent = formattedResults.efficiencyFactor;
    }
    
    /**
     * Update the visualization after a simulation run
     */
    updateVisualization() {
        try {
            console.log('Updating visualization...');
            
            // Update output displays
            this.updateOutputDisplays();
            
            // Ensure Charts are initialized before updating them
            if (!this.dailyOutputChart || !this.monthlyProductionChart) {
                console.log('Re-initializing charts...');
                this.initializeCharts();
            }
            
            // Update charts
            this.updateCharts();
            
            console.log('Visualization updated successfully');
        } catch (error) {
            console.error('Error updating visualization:', error);
            
            // Try to recover by re-initializing
            try {
                this.initializeCharts();
                this.updateCharts();
            } catch (recoveryError) {
                console.error('Failed to recover from error:', recoveryError);
            }
        }
    }
} 