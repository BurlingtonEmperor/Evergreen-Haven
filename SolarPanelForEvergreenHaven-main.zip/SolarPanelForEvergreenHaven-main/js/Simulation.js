/**
 * Class representing the solar panel simulation
 */
class Simulation {
    /**
     * Create a simulation
     * @param {SolarPanel} solarPanel - The solar panel system
     * @param {Environment} environment - The environment model
     */
    constructor(solarPanel, environment) {
        this.solarPanel = solarPanel;
        this.environment = environment;
        this.simulationResults = null;
        this.monthlyData = null;
        this.isRunning = false;
        this.currentHour = 12; // Default to noon
    }
    
    /**
     * Update the components with new configurations
     * @param {Object} panelConfig - Solar panel configuration
     * @param {Object} envConfig - Environment configuration
     */
    updateConfigurations(panelConfig, envConfig) {
        if (panelConfig) {
            this.solarPanel.updateConfig(panelConfig);
        }
        
        if (envConfig) {
            this.environment.updateConfig(envConfig);
        }
    }
    
    /**
     * Run the simulation for a day
     * @returns {Object} - Simulation results
     */
    runDailySimulation() {
        this.isRunning = true;
        
        // Generate environment data for the day
        const environmentData = this.environment.generateDailyData();
        
        // Calculate power output for each hour
        const dailyResults = this.solarPanel.estimateDailyProduction(this.environment);
        
        // Store the results
        this.simulationResults = {
            environmentData,
            ...dailyResults
        };
        
        this.isRunning = false;
        
        return this.simulationResults;
    }
    
    /**
     * Run a simulation for a year (monthly averages)
     * @returns {Object} - Monthly simulation results
     */
    runYearlySimulation() {
        this.isRunning = true;
        
        const months = [
            { name: 'Jan', season: 'winter', days: 31 },
            { name: 'Feb', season: 'winter', days: 28 },
            { name: 'Mar', season: 'spring', days: 31 },
            { name: 'Apr', season: 'spring', days: 30 },
            { name: 'May', season: 'spring', days: 31 },
            { name: 'Jun', season: 'summer', days: 30 },
            { name: 'Jul', season: 'summer', days: 31 },
            { name: 'Aug', season: 'summer', days: 31 },
            { name: 'Sep', season: 'autumn', days: 30 },
            { name: 'Oct', season: 'autumn', days: 31 },
            { name: 'Nov', season: 'autumn', days: 30 },
            { name: 'Dec', season: 'winter', days: 31 }
        ];
        
        // Store original season
        const originalSeason = this.environment.season;
        
        // Calculate monthly energy production
        const monthlyData = months.map(month => {
            // Set the season
            this.environment.updateConfig({ season: month.season });
            
            // Run daily simulation
            const dailyResults = this.runDailySimulation();
            
            // Calculate monthly value (daily energy * days in month)
            const monthlyEnergy = dailyResults.totalEnergy * month.days;
            
            return {
                month: month.name,
                season: month.season,
                days: month.days,
                dailyEnergy: dailyResults.totalEnergy,
                monthlyEnergy: monthlyEnergy
            };
        });
        
        // Restore original season
        this.environment.updateConfig({ season: originalSeason });
        
        // Store monthly data
        this.monthlyData = monthlyData;
        
        this.isRunning = false;
        
        return this.monthlyData;
    }
    
    /**
     * Get the current power output
     * @param {number} hour - Hour of the day (0-23)
     * @returns {number} - Current power output in Watts
     */
    getCurrentPowerOutput(hour = null) {
        // Use provided hour or current hour
        const timeOfDay = hour !== null ? hour : this.currentHour;
        
        // Get sun position for the specified hour
        const { sunElevation, sunAzimuth, irradiance } = this.environment.getSunPosition(timeOfDay);
        
        // Get temperature for the specified hour
        const temperature = this.environment.getTemperature(timeOfDay);
        
        // Calculate environmental conditions
        const conditions = {
            irradiance,
            temperature,
            sunElevation,
            sunAzimuth
        };
        
        // Calculate and return power output
        return this.solarPanel.calculatePowerOutput(conditions);
    }
    
    /**
     * Set the current hour
     * @param {number} hour - Hour of the day (0-23)
     */
    setCurrentHour(hour) {
        this.currentHour = Math.max(0, Math.min(23.99, hour));
    }
    
    /**
     * Get formatted results
     * @returns {Object} - Formatted simulation results
     */
    getFormattedResults() {
        if (!this.simulationResults) {
            return {
                currentOutput: '0 W',
                dailyEnergy: '0 kWh',
                peakPower: '0 W',
                efficiencyFactor: '0%'
            };
        }
        
        // Get current power output for the current hour
        const currentOutput = this.getCurrentPowerOutput();
        
        return {
            currentOutput: this.formatPower(currentOutput),
            dailyEnergy: this.formatEnergy(this.simulationResults.totalEnergy),
            peakPower: this.formatPower(this.simulationResults.peakPower),
            efficiencyFactor: `${Math.round(this.simulationResults.efficiencyFactor)}%`
        };
    }
    
    /**
     * Format power value for display
     * @param {number} power - Power in Watts
     * @returns {string} - Formatted power string
     */
    formatPower(power) {
        if (power >= 1000) {
            return `${(power / 1000).toFixed(2)} kW`;
        } else {
            return `${Math.round(power)} W`;
        }
    }
    
    /**
     * Format energy value for display
     * @param {number} energy - Energy in kWh
     * @returns {string} - Formatted energy string
     */
    formatEnergy(energy) {
        return `${energy.toFixed(2)} kWh`;
    }
} 