#!/bin/bash

echo "Checking for processes on port 3000 and 3001..."

# Check for processes on port 3000
PORT_3000_PID=$(lsof -i :3000 -t)
if [ -n "$PORT_3000_PID" ]; then
  echo "Killing process on port 3000 (PID: $PORT_3000_PID)"
  kill -9 $PORT_3000_PID
else
  echo "No process found on port 3000"
fi

# Check for processes on port 3001
PORT_3001_PID=$(lsof -i :3001 -t)
if [ -n "$PORT_3001_PID" ]; then
  echo "Killing process on port 3001 (PID: $PORT_3001_PID)"
  kill -9 $PORT_3001_PID
else
  echo "No process found on port 3001"
fi

echo "Done cleaning ports!" 