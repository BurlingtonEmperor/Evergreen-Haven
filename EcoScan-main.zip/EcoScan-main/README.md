# EcoScan

A web application that allows users to scan product barcodes and view their sustainability scores and environmental impact.

## Overview

EcoScan helps consumers make environmentally conscious purchasing decisions by providing detailed sustainability information about products. Users can enter a product barcode and instantly receive a sustainability score along with a breakdown of various environmental factors.

Key features:
- Barcode-based product lookup
- Overall sustainability scoring
- Visual breakdown of environmental impact factors (ecoscore, packaging, ingredients, origin)
- Detailed information about ingredients and packaging materials

## Technologies Used

### Backend
- Node.js
- Express.js
- Axios for API integration with Open Food Facts database

### Frontend
- React.js
- Chart.js for data visualization
- CSS for styling

## Installation

### Prerequisites
- Node.js (v14 or higher)
- npm (v6 or higher)

### Setup Instructions

1. Clone this repository:
```
git clone https://github.com/yourusername/ecoscan.git
cd ecoscan
```

2. Install dependencies for backend:
```
npm install
```

3. Navigate to the frontend directory and install dependencies:
```
cd frontend
npm install
```

4. Return to the root directory:
```
cd ..
```

5. Create a `.env` file in the root directory with the following content:
```
PORT=3001
```

## Running the Application

1. Start the backend server from the root directory:
```
npm start
```

2. In a separate terminal, start the frontend development server:
```
cd frontend
npm start
```

3. Open your browser and navigate to `http://localhost:3000`

## API Usage

The application uses the Open Food Facts API to retrieve product data. The backend server acts as a middleware that:
1. Receives barcode input from the frontend
2. Queries the Open Food Facts database
3. Processes the data to calculate sustainability scores
4. Returns formatted data to the frontend

### Example Product Barcodes for Testing

- Bananas: 4011
- Nutella: 3017620422003
- Tesco Salmon: 5057008564011
- Free-range Eggs: 0708080023287

## Project Structure

```
├── .env                  # Environment variables
├── package.json          # Backend dependencies and scripts
├── src/
│   └── server.js         # Express server and API handling
└── frontend/             # React frontend application
    ├── public/           # Static files
    └── src/              # React components and styles
        ├── App.js        # Main application component
        ├── App.css       # Application styles
        └── index.js      # Entry point
```

## License

MIT License

## Acknowledgements

- Data provided by [Open Food Facts](https://world.openfoodfacts.org/)
- Project created for educational purposes and sustainable consumption awareness 