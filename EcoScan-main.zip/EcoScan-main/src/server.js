const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3001;

// Enable CORS for all routes
app.use(cors({
  origin: 'http://localhost:3000',
  methods: ['GET', 'POST'],
  credentials: true
}));
app.use(express.json());

// Calculate sustainability score based on various factors
function calculateSustainabilityScore(product) {
  let score = 100;
  
  // Check ecoscore grade if available
  if (product.ecoscore_grade) {
    switch (product.ecoscore_grade.toLowerCase()) {
      case 'a':
        break; // Keep 100
      case 'b':
        score -= 20;
        break;
      case 'c':
        score -= 40;
        break;
      case 'd':
        score -= 60;
        break;
      case 'e':
        score -= 80;
        break;
    }
  }

  // Check for palm oil
  if (product.ingredients_analysis_tags) {
    if (product.ingredients_analysis_tags.includes('en:palm-oil')) {
      score -= 15;
    }
  }

  // Check packaging
  if (product.packaging_materials_tags) {
    if (product.packaging_materials_tags.includes('en:plastic')) {
      score -= 10;
    }
  }

  // Check for organic certification
  if (product.labels_tags) {
    if (product.labels_tags.some(label => label.includes('organic'))) {
      score += 10;
    }
  }

  // Check environmental impact from eco-score data
  if (product.ecoscore_data) {
    const impact = product.ecoscore_data.score;
    if (impact <= 20) {
      score -= 20;
    } else if (impact <= 40) {
      score -= 15;
    } else if (impact <= 60) {
      score -= 10;
    }
  }

  // Check for high carbon footprint ingredients
  if (product.ingredients) {
    const highImpactIngredients = ['en:beef', 'en:lamb', 'en:salmon', 'en:tuna'];
    const hasHighImpactIngredient = product.ingredients.some(ingredient => 
      highImpactIngredients.includes(ingredient.id)
    );
    if (hasHighImpactIngredient) {
      score -= 15;
    }
  }

  // Ensure score stays within 0-100 range
  return Math.max(0, Math.min(100, score));
}

// Get product sustainability rating
app.get('/api/product/:barcode', async (req, res) => {
  try {
    const { barcode } = req.params;
    console.log(`Fetching product data for barcode: ${barcode}`);
    
    const response = await axios.get(`https://world.openfoodfacts.org/api/v2/product/${barcode}.json`);
    console.log('Open Food Facts API response status:', response.status);
    
    if (response.data.status === 0) {
      console.log('Product not found in Open Food Facts database');
      return res.status(404).json({ error: 'Product not found in database' });
    }

    const product = response.data.product;
    if (!product) {
      return res.status(404).json({ error: 'Product data not available' });
    }

    const sustainabilityScore = calculateSustainabilityScore(product);

    const result = {
      barcode,
      name: product.product_name || 'Unknown Product',
      sustainabilityScore,
      details: {
        ecoscore_grade: product.ecoscore_grade || null,
        ecoscore_score: product.ecoscore_score || null,
        organic: product.labels_tags ? product.labels_tags.some(label => label.includes('organic')) : false,
        packaging: product.packaging || null,
        packaging_materials: product.packaging_materials_tags || [],
        ingredients: product.ingredients ? product.ingredients.map(ing => ({
          name: ing.text,
          percent: ing.percent_estimate,
          vegan: ing.vegan === 'yes',
          vegetarian: ing.vegetarian === 'yes'
        })) : [],
        palm_oil: product.ingredients_analysis_tags ? product.ingredients_analysis_tags.includes('en:palm-oil') : false,
        origins: product.origins || null,
        carbon_footprint: product.ecoscore_data ? {
          score: product.ecoscore_data.score,
          grade: product.ecoscore_data.grade
        } : null
      }
    };

    console.log('Sending response:', result);
    res.json(result);
  } catch (error) {
    console.error('Error details:', {
      message: error.message,
      response: error.response?.data,
      status: error.response?.status
    });
    
    if (error.response) {
      res.status(error.response.status).json({ 
        error: 'Failed to fetch product data',
        details: error.response.data
      });
    } else if (error.request) {
      res.status(503).json({ 
        error: 'No response received from Open Food Facts API',
        details: error.message
      });
    } else {
      res.status(500).json({ 
        error: 'Error processing request',
        details: error.message
      });
    }
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

const server = app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  console.log(`CORS enabled for origin: http://localhost:3000`);
});

// Handle errors
server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`Port ${port} is already in use. Trying port ${port + 1}`);
    setTimeout(() => {
      server.close();
      server.listen(port + 1, () => {
        console.log(`Server running on port ${port + 1}`);
        console.log(`CORS enabled for origin: http://localhost:3000`);
      });
    }, 1000);
  } else {
    console.error('Server error:', error);
  }
}); 