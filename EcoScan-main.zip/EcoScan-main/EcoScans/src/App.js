import React, { useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import axios from 'axios';
import './App.css';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const API_URL = 'http://localhost:3001/api';

function App() {
  const [barcode, setBarcode] = useState('');
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async () => {
    if (!barcode) {
      setError('Please enter a barcode');
      return;
    }

    setLoading(true);
    setError('');
    setProduct(null);

    try {
      const response = await axios.get(`${API_URL}/product/${barcode}`);
      setProduct(response.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Error fetching product data');
    } finally {
      setLoading(false);
    }
  };

  const renderScoreDetails = (details) => {
    const reasons = [];
    
    if (details.ecoscore_grade && details.ecoscore_grade !== 'unknown') {
      reasons.push(`Ecoscore Grade: ${details.ecoscore_grade.toUpperCase()}`);
    } else {
      reasons.push('Ecoscore Grade: Not Available');
    }
    
    if (details.packaging_materials?.includes('en:plastic')) {
      reasons.push('Contains plastic packaging');
    }
    
    if (details.origins && !details.origins.includes('France')) {
      reasons.push(`Imported from ${details.origins}`);
    }
    
    if (details.organic === false) {
      reasons.push('Not organic');
    }

    return reasons.map((reason, index) => (
      <div key={index} className="list-item">
        {reason}
      </div>
    ));
  };

  const SustainabilityChart = ({ details, sustainabilityScore }) => {
    const chartData = {
      labels: ['Overall Score', 'Ecoscore', 'Packaging', 'Ingredients', 'Origin'],
      datasets: [
        {
          label: 'Sustainability Metrics',
          data: [
            sustainabilityScore,
            details.ecoscore_score || 100,
            details.packaging_materials?.includes('en:plastic') ? 70 : 100,
            details.palm_oil ? 70 : 100,
            details.origins ? 100 : 0
          ],
          backgroundColor: [
            'rgba(46, 125, 50, 0.6)',
            details.ecoscore_score ? 'rgba(76, 175, 80, 0.6)' : 'rgba(128, 128, 128, 0.6)',
            'rgba(255, 160, 0, 0.6)',
            'rgba(245, 124, 0, 0.6)',
            'rgba(27, 94, 32, 0.6)'
          ],
          borderColor: [
            'rgba(46, 125, 50, 1)',
            details.ecoscore_score ? 'rgba(76, 175, 80, 1)' : 'rgba(128, 128, 128, 1)',
            'rgba(255, 160, 0, 1)',
            'rgba(245, 124, 0, 1)',
            'rgba(27, 94, 32, 1)'
          ],
          borderWidth: 2,
          borderRadius: 8
        }
      ]
    };

    const options = {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
          labels: {
            font: {
              size: 12,
              weight: 500
            }
          }
        },
        title: {
          display: true,
          text: 'Sustainability Score Breakdown',
          font: {
            size: 16,
            weight: 600
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const label = context.dataset.label || '';
              const value = context.parsed.y;
              const labelName = context.label;
              
              if (labelName === 'Ecoscore' && !details.ecoscore_score) {
                return `${label}: Unknown`;
              }
              return `${label}: ${value}%`;
            }
          },
          backgroundColor: 'rgba(255, 255, 255, 0.9)',
          titleColor: '#2E7D32',
          bodyColor: '#333',
          borderColor: '#4CAF50',
          borderWidth: 1,
          padding: 12,
          boxPadding: 6,
          usePointStyle: true,
          cornerRadius: 8,
          displayColors: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          max: 100,
          title: {
            display: true,
            text: 'Score',
            font: {
              size: 12,
              weight: 500
            }
          },
          grid: {
            color: 'rgba(0, 0, 0, 0.1)',
            drawBorder: false
          }
        },
        x: {
          grid: {
            display: false
          }
        }
      }
    };

    return (
      <div className="chart-container">
        <h2 className="chart-title">Sustainability Score Breakdown</h2>
        <div className="chart-wrapper">
          <Bar data={chartData} options={options} />
        </div>
      </div>
    );
  };

  return (
    <div className="app-container">
      <div className="header">
        <h1 className="title">EcoScan</h1>
        <p className="subtitle">
          Scan your products to discover their environmental impact and make sustainable choices
        </p>
      </div>
      
      <div className="search-container">
        <div className="search-box">
          <input
            type="text"
            placeholder="Enter Product Barcode"
            value={barcode}
            onChange={(e) => setBarcode(e.target.value)}
            className={error ? 'error' : ''}
          />
          {error && <p className="error-message">{error}</p>}
        </div>
        <button 
          onClick={handleSearch}
          disabled={loading}
          className="search-button"
        >
          {loading ? 'Scanning...' : 'Scan'}
        </button>
      </div>

      {product && (
        <div className="product-container">
          <div className="product-header">
            <h2>{product.name}</h2>
          </div>
          
          <div className="score-container">
            <div className="score">
              <span className="score-value">{product.sustainabilityScore}%</span>
              <span className="score-label">Overall Sustainability Score</span>
            </div>
          </div>

          <div className="details-container">
            <h3>Score Breakdown</h3>
            <div className="score-details">
              {renderScoreDetails(product.details)}
            </div>
          </div>

          <SustainabilityChart 
            details={product.details} 
            sustainabilityScore={product.sustainabilityScore} 
          />

          <div className="additional-info">
            <h3>Additional Information</h3>
            <div className="info-grid">
              <div className="info-section">
                <h4>Ingredients</h4>
                <div className="ingredients-list">
                  {product.details.ingredients.map((ingredient, index) => (
                    <div key={index} className="ingredient-item">
                      <span className="ingredient-name">{ingredient.name} ({ingredient.percent}%)</span>
                      <span className="ingredient-details">
                        {ingredient.vegan ? 'Vegan' : 'Non-vegan'} | {ingredient.vegetarian ? 'Vegetarian' : 'Non-vegetarian'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="info-section">
                <h4>Packaging</h4>
                <div className="packaging-list">
                  {product.details.packaging_materials.map((material, index) => (
                    <div key={index} className="packaging-item">
                      {material.replace('en:', '').replace(/-/g, ' ')}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
